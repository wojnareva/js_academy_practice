// add your functions here


// -------------------------
// ---- MAIN PROGRAM


console.log('hey buddy 😏');
